$(".bg-btn").on("click",
function() {
    generateBg();
} );

var bgParts =[
    '<div class="random bg"> <img src="bg1.jpg"></div>',
    '<div class="random bg"> <img src="bg2.jpg"></div>',
    '<div class="random bg"> <img src="bg3.jpg"></div>',
    '<div class="random bg"> <img src="bg4.jpg"></div>'
   
];
var bgNum = 0;
function generateBg() {
    var bgResult = bgParts[Math.floor(Math.random() * bgParts.length)];

  
    var uniqueId =  "bg" + bgNum++;

    $(bgResult).clone().addClass(uniqueId).appendTo(".bg-zn");
  
    var maxLeft = $(window).width() - $('.' + uniqueId).width();
    var maxTop = $(window).height() - $('.' + uniqueId).height();
  
    var leftPos = Math.floor(Math.random() * (maxLeft + 1));
    var topPos = Math.floor(Math.random() * (maxTop));
  
    $('.' + uniqueId).css({
      top: topPos,
      left: leftPos
    });
  
    $( ".bg" ).draggable({
      stack: '.bg'

    });
    $( ".bg" ).resizable();
  
    $( ".random" ).on( "dblclick", function() {
      $(this).hide();
    } );
  
  }
//   code for background 

$(".bd-btn").on("click",
    function() {
        generateBd();
    } );
    
    var bdParts =[
        '<img class="random bd" src="bg1.jpg"></img>',
        '<img class="random bd" src="bg2.jpg"></img>',
        '<img class="random bd" src="bg3.jpg"></img>',
        '<img class="random bd" src="bg4.jpg"></img>'
    ];
    var bdNum = 0;
    function generateBd() {
        var bdResult = bdParts[Math.floor(Math.random() * bdParts.length)];
    
      
        var uniqueId =  "bd" + bdNum++;
    
        // for eyes and mouth  dont change this
        $(bdResult).clone().addClass(uniqueId).appendTo(".bd-zn");
      
        var maxLeft = $(window).width() - $('.' + uniqueId).width();
        var maxTop = $(window).height() - $('.' + uniqueId).height();
      
        var leftPos = Math.floor(Math.random() * (maxLeft + 1));
        var topPos = Math.floor(Math.random() * (maxTop));
      
        $('.' + uniqueId).css({
          top: topPos,
          left: leftPos
        });
    //   this too
        $( ".bd" ).draggable({
          stack: '.bd'
        });
      
        $( ".random" ).on( "dblclick", function() {
          $(this).hide();
        } );
      
      }
